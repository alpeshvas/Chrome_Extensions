console.log("hey")
 $('#page-loader').remove();